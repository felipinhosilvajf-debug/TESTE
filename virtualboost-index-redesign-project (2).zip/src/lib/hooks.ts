"use client";

import { useEffect, useRef, useState } from "react";

/* =========================================================
   ECONOMIA EM TEMPO REAL — mesma origem e mesmo intervalo
   (5s) do projeto original. Estados: loading | live | error
========================================================= */
export type EconomyState =
    | { status: "loading"; value: number | null }
    | { status: "live"; value: number }
    | { status: "error"; value: number | null };

export function useEconomy(intervalMs = 5000) {
    const [state, setState] = useState<EconomyState>({ status: "loading", value: null });

    useEffect(() => {
        let alive = true;
        let timer: ReturnType<typeof setTimeout>;

        const tick = async () => {
            try {
                const res = await fetch("/api/economy", { cache: "no-store" });
                const data = (await res.json()) as { success?: boolean; adena?: number };
                if (!alive) return;
                if (data.success && typeof data.adena === "number") {
                    setState({ status: "live", value: data.adena });
                } else {
                    setState((prev) => ({ status: "error", value: prev.value }));
                }
            } catch {
                if (alive) setState((prev) => ({ status: "error", value: prev.value }));
            } finally {
                if (alive) timer = setTimeout(tick, intervalMs);
            }
        };

        tick();
        return () => {
            alive = false;
            clearTimeout(timer);
        };
    }, [intervalMs]);

    return state;
}

/* =========================================================
   TEMPO DESDE O LANÇAMENTO (2026-08-16, como no original)
========================================================= */
const LAUNCH_TS = new Date("2026-08-16T00:00:00-03:00").getTime();

export function useOnlineSince(): string {
    const [label, setLabel] = useState("0d 00h 00m 00s");

    useEffect(() => {
        const update = () => {
            const diff = Math.max(0, Date.now() - LAUNCH_TS);
            const s = Math.floor(diff / 1000);
            const d = Math.floor(s / 86400);
            const h = Math.floor((s % 86400) / 3600);
            const m = Math.floor((s % 3600) / 60);
            const sec = s % 60;
            setLabel(
                `${d}d ${String(h).padStart(2, "0")}h ${String(m).padStart(2, "0")}m ${String(sec).padStart(2, "0")}s`,
            );
        };
        update();
        const id = setInterval(update, 1000);
        return () => clearInterval(id);
    }, []);

    return label;
}

/* =========================================================
   NAVBAR SCROLLED
========================================================= */
export function useScrolled(threshold = 30): boolean {
    const [scrolled, setScrolled] = useState(false);
    useEffect(() => {
        const onScroll = () => setScrolled(window.scrollY > threshold);
        onScroll();
        window.addEventListener("scroll", onScroll, { passive: true });
        return () => window.removeEventListener("scroll", onScroll);
    }, [threshold]);
    return scrolled;
}

/* =========================================================
   REVEAL ON SCROLL — um único IntersectionObserver global.
   Registra observação para [data-reveal] já montados e para
   nós adicionados depois (MutationObserver leve, auto-encerra
   quando não há novos elementos).
========================================================= */
export function useRevealObserver() {
    const observerRef = useRef<IntersectionObserver | null>(null);

    useEffect(() => {
        if (typeof window === "undefined") return;
        document.documentElement.classList.add("has-js");

        const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        const io = new IntersectionObserver(
            (entries) => {
                for (const entry of entries) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add("is-shown");
                        io.unobserve(entry.target);
                    }
                }
            },
            { threshold: 0.12, rootMargin: "0px 0px -6% 0px" },
        );
        observerRef.current = io;

        const watch = (root: ParentNode) => {
            root.querySelectorAll<HTMLElement>("[data-reveal]:not(.is-shown)").forEach((el) => {
                if (reduce) {
                    el.classList.add("is-shown");
                } else {
                    io.observe(el);
                }
            });
        };

        watch(document);

        // elementos montados depois (ex.: modais) também recebem reveal
        let mutationDepth = 0;
        const mo = new MutationObserver((muts) => {
            for (const m of muts) {
                m.addedNodes.forEach((n) => {
                    if (n instanceof HTMLElement) {
                        if (n.matches?.("[data-reveal]")) watch(n);
                        watch(n);
                    }
                });
            }
            if (++mutationDepth > 40) mo.disconnect();
        });
        mo.observe(document.body, { childList: true, subtree: true });

        return () => {
            io.disconnect();
            mo.disconnect();
            observerRef.current = null;
        };
    }, []);
}

/* =========================================================
   TILT 3D SUTIL (desktop, pointer fine)
========================================================= */
export function useTilt<T extends HTMLElement = HTMLElement>(maxDeg = 4) {
    const ref = useRef<T | null>(null);

    useEffect(() => {
        const el = ref.current;
        if (!el) return;
        const fine = window.matchMedia("(pointer: fine)").matches;
        const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        if (!fine || reduce) return;

        let raf = 0;
        const onMove = (e: MouseEvent) => {
            const rect = el.getBoundingClientRect();
            const px = (e.clientX - rect.left) / rect.width - 0.5;
            const py = (e.clientY - rect.top) / rect.height - 0.5;
            cancelAnimationFrame(raf);
            raf = requestAnimationFrame(() => {
                el.style.transform = `perspective(900px) rotateX(${(-py * maxDeg).toFixed(2)}deg) rotateY(${(px * maxDeg).toFixed(2)}deg) translateY(-4px)`;
            });
        };
        const onLeave = () => {
            cancelAnimationFrame(raf);
            el.style.transform = "";
        };
        el.addEventListener("mousemove", onMove);
        el.addEventListener("mouseleave", onLeave);
        return () => {
            el.removeEventListener("mousemove", onMove);
            el.removeEventListener("mouseleave", onLeave);
            cancelAnimationFrame(raf);
        };
    }, [maxDeg]);

    return ref;
}
