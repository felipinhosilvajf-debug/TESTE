/**
 * Assets oficiais da VirtualBoost.
 * Os arquivos pesados (arte, gifs, video, logo) permanecem no domínio
 * original do site — preservando a identidade e os recursos existentes.
 * Os ícones da temporada (pequenos) foram copiados para /public/asset/season
 * para garantir o carregamento da roleta.
 */
export const SITE_ORIGIN = "https://virtualboost.online";

export const VB_ASSETS = {
    logo: `${SITE_ORIGIN}/logo.png`,
    heroVideo: `${SITE_ORIGIN}/asset/video1.mp4`,
    heroPoster: `${SITE_ORIGIN}/asset/back.png`,
    bg: {
        live: `${SITE_ORIGIN}/asset/hero-bg3.jpg`,
        features: `${SITE_ORIGIN}/asset/hero-bg2.jpg`,
        economy: `${SITE_ORIGIN}/asset/hero-bg4.png`,
        wiki: `${SITE_ORIGIN}/asset/herobg7.png`,
        final: `${SITE_ORIGIN}/asset/herobg77.png`,
    },
    cards: {
        progressao: `${SITE_ORIGIN}/asset/cards1.gif`,
        economia: `${SITE_ORIGIN}/asset/cards2.gif`,
        concorrencia: `${SITE_ORIGIN}/asset/card3.gif`,
        protecao: `${SITE_ORIGIN}/asset/card4.gif`,
        crafting: `${SITE_ORIGIN}/asset/card5.gif`,
        endgame: `${SITE_ORIGIN}/asset/card6.gif`,
        politica: `${SITE_ORIGIN}/asset/cards7.gif`,
        desafios: `${SITE_ORIGIN}/asset/card8.gif`,
    },
    season: {
        logo: "/asset/season/logo.png",
        mage3: "/asset/season/VBMage3.png",
        mage2: "/asset/season/VBMage2.png",
        mage1: "/asset/season/VBMage1.png",
        silver: "/asset/season/VBSilver.png",
        fight1: "/asset/season/VBFight1.png",
        fight2: "/asset/season/VBFight2.png",
        fight3: "/asset/season/VBFight3.png",
        gold: "/asset/season/VBGold.png",
    },
    links: {
        login: `${SITE_ORIGIN}/site/login.php`,
        discord: "https://discord.gg/sFjMVvW3R",
        facebook: "https://www.facebook.com/profile.php?id=61593743825503",
        downloadLauncher: `${SITE_ORIGIN}/download/VBoost-Launcher.zip`,
        downloadClientRar: `${SITE_ORIGIN}/download/L2H5-Client.rar`,
        downloadMediafire:
            "https://www.mediafire.com/file/fduprchyyotwej2/L2+High+Five+Original.zip/file",
        youtubeLive: "https://www.youtube.com/embed/Jr2Gzqln-lQ",
    },
} as const;
