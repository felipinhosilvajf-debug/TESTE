import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Cinzel, Cinzel_Decorative, EB_Garamond } from "next/font/google";
import "./globals.css";

const cinzel = Cinzel({
    subsets: ["latin"],
    weight: ["400", "600", "700", "800", "900"],
    variable: "--font-cinzel",
    display: "swap",
});

const cinzelDecorative = Cinzel_Decorative({
    subsets: ["latin"],
    weight: ["700", "900"],
    variable: "--font-cinzel-deco",
    display: "swap",
});

const garamond = EB_Garamond({
    subsets: ["latin"],
    weight: ["400", "500", "600"],
    style: ["normal", "italic"],
    variable: "--font-eb-garamond",
    display: "swap",
});

export const metadata: Metadata = {
    title: "L2 Virtual Boost — High Five",
    description:
        "O Virtual Boost leva você a uma experiência MMORPG expansiva onde você cria o seu próprio destino.",
    icons: {
        icon: "https://virtualboost.online/ico2.png",
    },
};

export const viewport: Viewport = {
    themeColor: "#070a10",
};

export default function RootLayout({ children }: { children: ReactNode }) {
    return (
        <html lang="pt-BR" className={`${cinzel.variable} ${cinzelDecorative.variable} ${garamond.variable}`}>
            <head>
                <script
                    dangerouslySetInnerHTML={{
                        __html: "document.documentElement.classList.add('has-js')",
                    }}
                />
            </head>
            <body className="[--font-display:var(--font-cinzel),serif][--font-deco:var(--font-cinzel-deco),serif][--font-body:var(--font-eb-garamond),serif] antialiased">
                {children}
            </body>
        </html>
    );
}
