import { db } from "@/db";
import { sql } from "drizzle-orm";
import ClientShell from "@/components/ClientShell";

export const dynamic = "force-dynamic";

export default async function HomePage() {
    // Sonda de integridade do backend (PostgreSQL via Drizzle)
    await db.execute(sql`select 1`);

    return <ClientShell />;
}
