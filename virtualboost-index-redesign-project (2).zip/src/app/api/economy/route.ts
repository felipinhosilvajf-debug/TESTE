import { NextResponse } from "next/server";

/**
 * Proxy para a economia em tempo real do reino.
 * Mantém a fonte de dados original (site/api/economy.php) do VirtualBoost
 * sem expor chamadas cross-origin directas do navegador.
 * Nenhum valor é inventado: se a origem não responder, devolve {success:false}.
 */
export const dynamic = "force-dynamic";

const UPSTREAM =
    process.env.VB_ECONOMY_URL ??
    "https://virtualboost.online/site/api/economy.php";

export async function GET(req: Request) {
    try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 8000);
        const res = await fetch(`${UPSTREAM}?t=${Date.now()}`, {
            cache: "no-store",
            signal: controller.signal,
        });
        clearTimeout(timer);
        if (!res.ok) {
            return NextResponse.json({ success: false, error: "upstream" });
        }
        const data = (await res.json()) as { success?: boolean; adena?: number };
        if (data && data.success && typeof data.adena === "number") {
            return NextResponse.json({ success: true, adena: data.adena });
        }
        return NextResponse.json({ success: false, error: "payload" });
    } catch {
        return NextResponse.json({ success: false, error: "network" });
    }
}
