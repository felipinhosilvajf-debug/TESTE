"use client";

import { useEffect, useRef, useState } from "react";

/* =========================================================
   PARTÍCULAS ARCANAS — um único canvas fixo, leve,
   com menos partículas em telas pequenas e sem rAF
   sob prefers-reduced-motion (renderiza pontos estáticos).
========================================================= */
interface P {
    x: number;
    y: number;
    r: number;
    vy: number;
    vx: number;
    phase: number;
    tw: number;
    hue: number;
}

export function ParticleField() {
    const canvasRef = useRef<HTMLCanvasElement | null>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext("2d");
        if (!ctx) return;

        const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        let w = 0,
            h = 0,
            raf = 0;
        let particles: P[] = [];
        let running = true;

        const dpr = Math.min(window.devicePixelRatio || 1, 1.5);

        const build = () => {
            w = window.innerWidth;
            h = window.innerHeight;
            canvas.width = Math.floor(w * dpr);
            canvas.height = Math.floor(h * dpr);
            canvas.style.width = `${w}px`;
            canvas.style.height = `${h}px`;
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

            const count = w < 700 ? 22 : w < 1200 ? 42 : 64;
            particles = Array.from({ length: count }, () => ({
                x: Math.random() * w,
                y: Math.random() * h,
                r: 0.6 + Math.random() * 1.6,
                vy: -(0.05 + Math.random() * 0.22),
                vx: (Math.random() - 0.5) * 0.08,
                phase: Math.random() * Math.PI * 2,
                tw: 0.4 + Math.random() * 1.2,
                hue: 195 + Math.random() * 22,
            }));
        };

        const draw = (t: number) => {
            ctx.clearRect(0, 0, w, h);
            for (const p of particles) {
                const a = 0.16 + 0.5 * Math.abs(Math.sin(t * 0.0004 * p.tw + p.phase));
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
                ctx.fillStyle = `hsla(${p.hue}, 92%, 68%, ${a})`;
                ctx.fill();
            }
        };

        const step = (t: number) => {
            if (!running) return;
            for (const p of particles) {
                p.y += p.vy;
                p.x += p.vx + Math.sin(t * 0.0003 + p.phase) * 0.05;
                if (p.y < -8) {
                    p.y = h + 8;
                    p.x = Math.random() * w;
                }
                if (p.x < -8) p.x = w + 8;
                if (p.x > w + 8) p.x = -8;
            }
            draw(t);
            raf = requestAnimationFrame(step);
        };

        const onResize = () => {
            build();
            if (reduce) draw(0);
        };
        const onVis = () => {
            if (reduce) return;
            if (document.hidden) {
                running = false;
                cancelAnimationFrame(raf);
            } else if (!running) {
                running = true;
                raf = requestAnimationFrame(step);
            }
        };

        build();
        if (reduce) {
            draw(0);
        } else {
            raf = requestAnimationFrame(step);
        }
        window.addEventListener("resize", onResize, { passive: true });
        document.addEventListener("visibilitychange", onVis);

        return () => {
            running = false;
            cancelAnimationFrame(raf);
            window.removeEventListener("resize", onResize);
            document.removeEventListener("visibilitychange", onVis);
        };
    }, []);

    return <canvas ref={canvasRef} className="vb-particles" aria-hidden="true" />;
}

/* =========================================================
   GLOW DE CURSOR — desktop (pointer fine) apenas,
   não substitui o cursor nativo, segue com lerp suave.
========================================================= */
export function CursorGlow() {
    const ref = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
        const el = ref.current;
        if (!el) return;
        const fine = window.matchMedia("(pointer: fine)").matches;
        const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        if (!fine || reduce) return;

        let raf = 0;
        let tx = -600,
            ty = -600,
            cx = -600,
            cy = -600;
        const onMove = (e: MouseEvent) => {
            tx = e.clientX;
            ty = e.clientY;
            el.classList.add("is-on");
        };
        const onLeave = () => el.classList.remove("is-on");
        const loop = () => {
            cx += (tx - cx) * 0.12;
            cy += (ty - cy) * 0.12;
            el.style.transform = `translate3d(${cx.toFixed(1)}px, ${cy.toFixed(1)}px, 0)`;
            raf = requestAnimationFrame(loop);
        };
        window.addEventListener("mousemove", onMove, { passive: true });
        document.documentElement.addEventListener("mouseleave", onLeave);
        raf = requestAnimationFrame(loop);
        return () => {
            window.removeEventListener("mousemove", onMove);
            document.documentElement.removeEventListener("mouseleave", onLeave);
            cancelAnimationFrame(raf);
        };
    }, []);

    return <div ref={ref} className="vb-cursor-glow" aria-hidden="true" />;
}

/* =========================================================
   RETORNAR AO TOPO + FLUTUANTE DO DISCORD
========================================================= */
export function Floats({ onDiscord }: { onDiscord: () => void }) {
    const [show, setShow] = useState(false);

    useEffect(() => {
        const onScroll = () => setShow(window.scrollY > 650);
        onScroll();
        window.addEventListener("scroll", onScroll, { passive: true });
        return () => window.removeEventListener("scroll", onScroll);
    }, []);

    return (
        <div className="vb-floats">
            <button
                type="button"
                className={`vb-top${show ? " is-visible" : ""}`}
                aria-label="Voltar ao topo"
                onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            >
                <svg viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M12 19V5M5 12l7-7 7 7" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
            </button>
            <button
                type="button"
                className="vb-discord-float"
                aria-label="Discord Virtual Boost"
                onClick={onDiscord}
            >
                <svg viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M19.7 5.3A18.8 18.8 0 0 0 15 3.8l-.6 1.2a17.2 17.2 0 0 0-4.8 0L9 3.8a18.8 18.8 0 0 0-4.7 1.5C1.3 9.7.5 14 .9 18.2a19 19 0 0 0 5.8 2.9l1.2-2a12 12 0 0 1-1.9-.9l.5-.4a13.5 13.5 0 0 0 11 0l.5.4a12 12 0 0 1-1.9.9l1.2 2a19 19 0 0 0 5.8-2.9c.5-4.9-.8-9.2-3.4-12.9ZM8.7 15.2c-1.1 0-2-1-2-2.2s.9-2.2 2-2.2 2 1 2 2.2-.9 2.2-2 2.2Zm6.6 0c-1.1 0-2-1-2-2.2s.9-2.2 2-2.2 2 1 2 2.2-.9 2.2-2 2.2Z" />
                </svg>
            </button>
        </div>
    );
}
