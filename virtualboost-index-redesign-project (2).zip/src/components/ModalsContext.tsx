"use client";

import {
    createContext,
    useCallback,
    useContext,
    useEffect,
    useRef,
    useState,
    type ReactNode,
} from "react";
import { VB_ASSETS } from "@/lib/assets";
import { useEconomy } from "@/lib/hooks";

export type PanelKey =
    | "server"
    | "philosophy"
    | "rates"
    | "economy"
    | "download"
    | "join";

interface ModalsCtx {
    openPanel: (key: PanelKey) => void;
    closePanel: () => void;
}

const Ctx = createContext<ModalsCtx>({ openPanel: () => {}, closePanel: () => {} });

export const useModals = () => useContext(Ctx);

const PANEL_META: Record<PanelKey, { ico: string; title: string }> = {
    server: { ico: "♛", title: "O REINO" },
    philosophy: { ico: "◈", title: "FILOSOFIA" },
    rates: { ico: "⚔", title: "RATES" },
    economy: { ico: "✦", title: "ECONOMIA" },
    download: { ico: "✦", title: "DOWNLOAD" },
    join: { ico: "⚔", title: "COMUNIDADE" },
};

export function ModalsProvider({ children }: { children: ReactNode }) {
    const [open, setOpen] = useState<PanelKey | null>(null);
    const windowRef = useRef<HTMLDivElement | null>(null);

    const openPanel = useCallback((key: PanelKey) => setOpen(key), []);
    const closePanel = useCallback(() => setOpen(null), []);

    useEffect(() => {
        if (!open) return;
        document.body.classList.add("modal-open");
        const onKey = (e: KeyboardEvent) => {
            if (e.key === "Escape") setOpen(null);
        };
        document.addEventListener("keydown", onKey);
        windowRef.current?.scrollTo({ top: 0 });
        return () => {
            document.body.classList.remove("modal-open");
            document.removeEventListener("keydown", onKey);
        };
    }, [open]);

    return (
        <Ctx.Provider value={{ openPanel, closePanel }}>
            {children}

            {(Object.keys(PANEL_META) as PanelKey[]).map((key) => (
                <div
                    key={key}
                    className={`vb-modal${open === key ? " open" : ""}`}
                    role="dialog"
                    aria-modal="true"
                    aria-hidden={open !== key}
                    aria-label={PANEL_META[key].title}
                >
                    <div className="vb-modal-backdrop" onClick={closePanel} />
                    <div
                        className="vb-modal-window"
                        ref={open === key ? windowRef : undefined}
                    >
                        <div className="vb-modal-head">
                            <div className="vb-modal-title">
                                <span className="vb-modal-ico" aria-hidden="true">
                                    {PANEL_META[key].ico}
                                </span>
                                {PANEL_META[key].title}
                            </div>
                            <button
                                type="button"
                                className="vb-modal-close"
                                aria-label="Fechar"
                                onClick={closePanel}
                            >
                                ×
                            </button>
                        </div>
                        <div className="vb-modal-body">
                            {key === "server" && <PanelServer />}
                            {key === "philosophy" && <PanelPhilosophy />}
                            {key === "rates" && <PanelRates />}
                            {key === "economy" && <PanelEconomy />}
                            {key === "download" && <PanelDownload />}
                            {key === "join" && <PanelJoin />}
                        </div>
                    </div>
                </div>
            ))}
        </Ctx.Provider>
    );
}

/* =========================================================
   PAINEL — O REINO (8 sistemas)
========================================================= */
const SERVER_CARDS = [
    {
        img: VB_ASSETS.cards.progressao,
        title: "Progressão Dinâmica",
        text: "XP e SP aceleram a evolução, reduzindo a espera sem transformar o personagem em algo pronto.",
    },
    {
        img: VB_ASSETS.cards.economia,
        title: "Economia Viva",
        text: "Adena, materiais, crafting e itens raros possuem importância real dentro do reino. Adena em tempo real, com acompanhamento transparente da economia do servidor.",
    },
    {
        img: VB_ASSETS.cards.concorrencia,
        title: "Clãs & Conquistas",
        text: "Siege, territórios, alianças e guerras entre clãs fazem parte da verdadeira disputa pelo poder.",
    },
    {
        img: VB_ASSETS.cards.protecao,
        title: "Proteção Ativa",
        text: "Ambiente competitivo com atenção constante contra bots, exploits e comportamentos abusivos.",
    },
    {
        img: VB_ASSETS.cards.crafting,
        title: "Crafting Relevante",
        text: "Produzir, coletar e negociar são partes importantes da economia do servidor.",
    },
    {
        img: VB_ASSETS.cards.endgame,
        title: "Endgame com Propósito",
        text: "O endgame não representa o fim. Ele abre espaço para guerras, território, comércio e reconhecimento.",
    },
    {
        img: VB_ASSETS.cards.politica,
        title: "Política & Alianças",
        text: "Sozinho você conquista território. Com aliados você pode construir um império.",
    },
    {
        img: VB_ASSETS.cards.desafios,
        title: "Desafios Dinâmicos",
        text: "Eventos de mundo e desafios especiais mantêm a comunidade em constante movimento.",
    },
];

function PanelServer() {
    return (
        <>
            <h2 className="vb-title" style={{ fontSize: "clamp(1.5rem,3vw,2.2rem)" }}>
                <span className="accent">O REINO</span> EM NOVO RITMO
            </h2>
            <p className="vb-lead">
                Um servidor baseado na essência clássica do <strong>Lineage II High Five</strong>,
                agora com uma progressão 10X mais dinâmica, sem abrir mão da sensação de evolução,
                perigo e conquista. Aqui você evolui mais rápido para chegar ao conteúdo que
                realmente importa: PvP, clãs, comércio, guerras e conquistas.
            </p>
            <div className="vb-modal-cards">
                {SERVER_CARDS.map((c) => (
                    <div className="vb-mcard" key={c.title}>
                        <img src={c.img} alt={c.title} loading="lazy" />
                        <h3>{c.title}</h3>
                        <p>{c.text}</p>
                    </div>
                ))}
            </div>
        </>
    );
}

/* =========================================================
   PAINEL — FILOSOFIA
========================================================= */
const PHIL_CARDS = [
    {
        ico: "◈",
        title: "RITMO CERTO",
        text: "A progressão ganha ritmo sem perder a sensação de evolução e conquista.",
    },
    {
        ico: "⚔",
        title: "DIFÍCIL DE DOMINAR",
        text: "A evolução é mais ágil, mas equipamento, estratégia, comércio e trabalho em equipe continuam fazendo a diferença.",
    },
    {
        ico: "♛",
        title: "CONQUISTE",
        text: "Grandes itens e títulos devem carregar uma história. O poder precisa ser conquistado.",
    },
];

function PanelPhilosophy() {
    return (
        <>
            <h2 className="vb-title" style={{ fontSize: "clamp(1.5rem,3vw,2.2rem)" }}>
                <span className="accent">A FILOSOFIA</span> DO VIRTUAL BOOST
            </h2>
            <p className="vb-lead">
                Não queremos eliminar a jornada. <strong>Queremos dar mais ritmo à evolução e manter
                o valor de cada conquista.</strong>
            </p>
            <div className="vb-phil-cards">
                {PHIL_CARDS.map((c) => (
                    <div className="vb-phil" key={c.title}>
                        <div className="vb-phil-ico" aria-hidden="true">
                            {c.ico}
                        </div>
                        <h3>{c.title}</h3>
                        <p>{c.text}</p>
                    </div>
                ))}
            </div>
        </>
    );
}

/* =========================================================
   PAINEL — RATES (x10, como no original)
========================================================= */
const RATES = [
    { target: 10, label: "XP Rate" },
    { target: 10, label: "SP Rate" },
    { target: 10, label: "Adena Rate" },
];

function RateCounter({ target }: { target: number }) {
    const [n, setN] = useState(0);
    const ref = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
        const el = ref.current;
        if (!el) return;
        const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        if (reduce) {
            setN(target);
            return;
        }
        let raf = 0;
        const io = new IntersectionObserver(
            (entries) => {
                if (!entries.some((e) => e.isIntersecting)) return;
                io.disconnect();
                let current = 0;
                const animate = () => {
                    current += Math.max(1, Math.ceil(target / 15));
                    if (current >= target) {
                        setN(target);
                        return;
                    }
                    setN(current);
                    raf = requestAnimationFrame(animate);
                };
                animate();
            },
            { threshold: 0.6 },
        );
        io.observe(el);
        return () => {
            io.disconnect();
            cancelAnimationFrame(raf);
        };
    }, [target]);

    return (
        <div ref={ref} className="vb-rate-num">
            x{n}
        </div>
    );
}

function PanelRates() {
    return (
        <>
            <h2 className="vb-title" style={{ fontSize: "clamp(1.5rem,3vw,2.2rem)" }}>
                <span className="accent">RATES</span> DO REINO
            </h2>
            <p className="vb-lead">
                As principais taxas do servidor, apresentadas de forma clara para você saber
                exatamente como funciona a progressão e a economia.
            </p>
            <div className="vb-rates">
                {RATES.map((r) => (
                    <div className="vb-rate" key={r.label}>
                        <RateCounter target={r.target} />
                        <div className="vb-rate-lbl">{r.label}</div>
                    </div>
                ))}
            </div>
        </>
    );
}

/* =========================================================
   PAINEL — ECONOMIA EM TEMPO REAL
========================================================= */
const CASTLES = ["Aden", "Giran", "Rune", "Schuttgart"];
const KING_COINS = [
    {
        name: "Adena",
        role: "Base da economia: comércio, equipamentos, crafting e negociações.",
    },
    {
        name: "VBSilver",
        role: "Moeda de atividade: obtida através de eventos, PvP, missões e participação no servidor.",
    },
    {
        name: "VBGold",
        role: "Moeda de prestígio: destinada a recompensas raras, conteúdo especial e progressão de endgame.",
    },
];

function PanelEconomy() {
    const econ = useEconomy();
    const fmt = new Intl.NumberFormat("pt-BR");

    return (
        <>
            <h2 className="vb-title" style={{ fontSize: "clamp(1.5rem,3vw,2.2rem)" }}>
                <span className="accent">ECONOMIA</span> EM TEMPO REAL
            </h2>
            <p className="vb-lead">
                Monitoramento analítico extraído diretamente das tabelas do servidor.{" "}
                <strong>Transparência sobre Adena em circulação, impostos e domínios.</strong>
            </p>

            <div className="vb-econ-stats">
                <div className="vb-estat">
                    <div className="vb-estat-head">
                        <span>Adena em Circulação</span>
                        <span className="vb-dot" style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--blue-base)", boxShadow: "0 0 10px var(--glow-cyan)" }} />
                    </div>
                    <div
                        className={`vb-estat-val${econ.status !== "live" ? " is-loading" : ""}`}
                        style={{ color: "var(--gold-bright)" }}
                    >
                        {econ.status === "live"
                            ? fmt.format(econ.value)
                            : econ.status === "error"
                              ? "SEM DADOS"
                              : "SINCRONIZANDO…"}
                    </div>
                    <div className="vb-estat-foot">
                        Atualização em tempo real a cada 5 segundos.
                    </div>
                </div>
                <div className="vb-estat">
                    <div className="vb-estat-head">
                        <span>Tesouro dos Castelos</span>
                    </div>
                    <div className="vb-estat-val">9.000.000</div>
                    <div className="vb-estat-foot">Acumulado via Taxas de Domínio</div>
                </div>
                <div className="vb-estat">
                    <div className="vb-estat-head">
                        <span>Volume de Transações (24h)</span>
                    </div>
                    <div className="vb-estat-val">195 Itens</div>
                    <div className="vb-estat-foot">Movimentações no Auction / Trade</div>
                </div>
            </div>

            <div className="vb-econ-tables">
                <div className="vb-dpanel">
                    <div className="vb-dpanel-title">DOMÍNIO DE CASTELOS (SIEGE)</div>
                    <table className="vb-dtable">
                        <thead>
                            <tr>
                                <th>Castelo</th>
                                <th>Clã Proprietário</th>
                                <th>Taxa de Imposto</th>
                            </tr>
                        </thead>
                        <tbody>
                            {CASTLES.map((c) => (
                                <tr key={c}>
                                    <td>
                                        <strong>{c}</strong>
                                    </td>
                                    <td>
                                        <span className="vb-clan-tag">Estado</span>
                                    </td>
                                    <td>
                                        <span className="vb-tax-badge">0%</span>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                <div className="vb-dpanel">
                    <div className="vb-dpanel-title">MOEDAS DO REINO</div>
                    <table className="vb-dtable">
                        <thead>
                            <tr>
                                <th>Moeda</th>
                                <th>Função</th>
                            </tr>
                        </thead>
                        <tbody>
                            {KING_COINS.map((c) => (
                                <tr key={c.name}>
                                    <td>
                                        <strong>{c.name}</strong>
                                    </td>
                                    <td>{c.role}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </>
    );
}

/* =========================================================
   PAINEL — DOWNLOAD
========================================================= */
const DOWNLOAD_ROWS = [
    {
        file: "LAUNCHER",
        tag: "OPÇÃO 1 · .ZIP",
        desc: "Baixe a versão pronta para inicialização e extraia na pasta raiz do Lineage II.",
        href: VB_ASSETS.links.downloadLauncher,
        action: "BAIXAR",
        external: false,
    },
    {
        file: "CLIENTE HIGH FIVE",
        tag: ".TORRENT",
        desc: "Download completo do cliente High Five através de torrent.",
        href: VB_ASSETS.links.downloadClientRar,
        action: "TORRENT",
        external: true,
    },
    {
        file: "CLIENTE HIGH FIVE",
        tag: ".ZIP · MEDIAFIRE",
        desc: "Download completo do cliente High Five através do MediaFire.",
        href: VB_ASSETS.links.downloadMediafire,
        action: "MEDIAFIRE",
        external: true,
    },
];

function PanelDownload() {
    return (
        <div className="vb-download-grid">
            <div className="vb-download-visual">
                <img src={VB_ASSETS.cards.concorrencia} alt="Visual do Servidor" loading="lazy" />
            </div>
            <div className="vb-download-text">
                <h3>
                    Faça o <br />
                    <span>Clients</span>
                </h3>
                <p>Aqui, uma arma rara não é apenas um item no inventário.</p>
                <p>
                    Ela representa horas de dedicação, um raid inesquecível, uma guerra vencida ou
                    uma negociação histórica.
                </p>
                <p>
                    Entre no reino, evolua no seu ritmo e descubra até onde sua própria história
                    pode chegar.
                </p>

                <div className="vb-dl-rows">
                    {DOWNLOAD_ROWS.map((r) => (
                        <div className="vb-dl-row" key={r.file + r.tag}>
                            <div className="vb-dl-file">
                                <b>{r.file}</b>
                                <small>{r.tag}</small>
                            </div>
                            <a
                                href={r.href}
                                className="vb-dl-btn"
                                target={r.external ? "_blank" : undefined}
                                rel={r.external ? "noreferrer" : undefined}
                            >
                                {r.action}
                            </a>
                            <div className="vb-dl-desc">{r.desc}</div>
                        </div>
                    ))}
                </div>

                <div className="vb-dl-notice">
                    <b>ATENÇÃO</b> — Após baixar o client, delete a <strong>system</strong> e
                    execute o <strong>Launcher</strong> para manter os arquivos atualizados.
                </div>

                <div className="vb-dl-bottom">
                    <a
                        href={VB_ASSETS.links.downloadLauncher}
                        className="vb-btn vb-btn--gold"
                        style={{ padding: "13px 22px" }}
                    >
                        Launcher (3mb)
                    </a>
                    <span className="vb-dl-help">Launcher com apenas 3mb! Contém a system completa!</span>
                </div>
            </div>
        </div>
    );
}

/* =========================================================
   PAINEL — COMUNIDADE
========================================================= */
function PanelJoin() {
    return (
        <div className="vb-join-cta">
            <h3>
                SUA LENDA <span>COMEÇA AQUI</span>
            </h3>
            <p>
                Prepare seu personagem, reúna seus aliados e entre em um High Five com mais
                ritmo, mais atividade e espaço para conquistar o endgame.
            </p>
            <div className="vb-join-btns">
                <a className="vb-btn" href={VB_ASSETS.links.facebook} target="_blank" rel="noreferrer">
                    FACEBOOK
                </a>
                <a className="vb-btn" href={VB_ASSETS.links.discord} target="_blank" rel="noreferrer">
                    DISCORD
                </a>
            </div>
        </div>
    );
}
