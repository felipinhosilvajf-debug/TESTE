"use client";

import { VB_ASSETS } from "@/lib/assets";
import { useModals } from "./ModalsContext";

export default function Footer() {
    const { openPanel } = useModals();

    return (
        <footer className="vb-footer">
            <div className="vb-wrap">
                <img src={VB_ASSETS.season.logo} alt="" width={46} height={46} loading="lazy" />
                <p>© 2026 L2 Virtual Boost — Projeto independente e não-oficial de fãs.</p>
                <nav className="vb-footer-links" aria-label="Links do rodapé">
                    <a href="#home">INÍCIO</a>
                    <a href="#features">O REINO</a>
                    <a href="#progressao">PROGRESSÃO</a>
                    <a href="#wiki">WIKI</a>
                    <a
                        href="#"
                        onClick={(e) => {
                            e.preventDefault();
                            openPanel("join");
                        }}
                    >
                        DISCORD
                    </a>
                </nav>
            </div>
        </footer>
    );
}
