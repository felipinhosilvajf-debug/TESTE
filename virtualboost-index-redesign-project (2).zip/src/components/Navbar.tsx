"use client";

import { useState } from "react";
import { VB_ASSETS } from "@/lib/assets";
import { useEconomy, useScrolled } from "@/lib/hooks";
import { useModals } from "./ModalsContext";

const NAV_LINKS = [
    { href: "#home", label: "INÍCIO" },
    { href: "#novidades", label: "NOVIDADES" },
    { href: "#features", label: "O REINO" },
    { href: "#progressao", label: "PROGRESSÃO" },
    { href: "#wiki", label: "WIKI" },
];

export default function Navbar() {
    const { openPanel } = useModals();
    const scrolled = useScrolled(40);
    const [active, setActive] = useState("#home");
    const [mobileOpen, setMobileOpen] = useState(false);
    const econ = useEconomy();
    const fmt = new Intl.NumberFormat("pt-BR");

    const adenaLabel =
        econ.status === "live"
            ? fmt.format(econ.value)
            : econ.status === "error"
              ? "—"
              : "Carregando…";

    const onNavClick = (href: string) => {
        setActive(href);
        setMobileOpen(false);
    };

    return (
        <header className={`vb-nav${scrolled ? " is-scrolled" : ""}`}>
            <div className="vb-nav-inner">
                <a
                    className="vb-brand"
                    href="#home"
                    aria-label="Virtual Boost — início"
                    onClick={() => onNavClick("#home")}
                >
                    <img src={VB_ASSETS.season.logo} alt="" width={38} height={38} />
                    <span className="vb-brand-name">
                        VIRTUAL <b>BOOST</b>
                    </span>
                </a>

                <nav className="vb-nav-links" aria-label="Navegação principal">
                    {NAV_LINKS.map((l) => (
                        <a
                            key={l.href}
                            href={l.href}
                            className={active === l.href ? "is-active" : ""}
                            onClick={() => onNavClick(l.href)}
                        >
                            {l.label}
                        </a>
                    ))}
                    <a href="#" onClick={(e) => { e.preventDefault(); setMobileOpen(false); openPanel("join"); }}>
                        DISCORD
                    </a>
                </nav>

                <div className="vb-nav-account">
                    <div className="vb-nav-adena" title="Adena em circulação — atualização a cada 5s">
                        <span>
                            <i className="vb-dot" aria-hidden="true" />
                            ADENA EM CIRCULAÇÃO
                        </span>
                        <strong>{adenaLabel}</strong>
                    </div>
                    <a className="vb-nav-login" href={VB_ASSETS.links.login} target="_blank" rel="noreferrer">
                        LOGIN
                    </a>
                    <button
                        type="button"
                        className="vb-nav-btn"
                        onClick={() => {
                            setMobileOpen(false);
                            openPanel("download");
                        }}
                    >
                        DOWNLOAD
                    </button>
                    <button
                        type="button"
                        className="vb-nav-mobile"
                        aria-label={mobileOpen ? "Fechar menu" : "Abrir menu"}
                        aria-expanded={mobileOpen}
                        onClick={() => setMobileOpen((v) => !v)}
                    >
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                            {mobileOpen ? (
                                <path d="M6 6l12 12M18 6L6 18" />
                            ) : (
                                <path d="M4 7h16M4 12h16M4 17h16" />
                            )}
                        </svg>
                    </button>
                </div>

                <nav
                    className={`vb-mobile-menu${mobileOpen ? " open" : ""}`}
                    aria-label="Menu móvel"
                >
                    {NAV_LINKS.map((l) => (
                        <a key={l.href} href={l.href} onClick={() => onNavClick(l.href)}>
                            {l.label}
                        </a>
                    ))}
                    <a
                        href="#"
                        onClick={(e) => {
                            e.preventDefault();
                            setMobileOpen(false);
                            openPanel("join");
                        }}
                    >
                        DISCORD
                    </a>
                    <a href={VB_ASSETS.links.login} target="_blank" rel="noreferrer">
                        LOGIN
                    </a>
                    <a
                        href="#"
                        onClick={(e) => {
                            e.preventDefault();
                            setMobileOpen(false);
                            openPanel("download");
                        }}
                    >
                        DOWNLOAD
                    </a>
                </nav>
            </div>
        </header>
    );
}
