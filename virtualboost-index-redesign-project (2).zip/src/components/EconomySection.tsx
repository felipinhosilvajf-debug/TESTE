"use client";

import { VB_ASSETS } from "@/lib/assets";
import { useEconomy } from "@/lib/hooks";
import { useModals } from "./ModalsContext";

export default function EconomySection() {
    const { openPanel } = useModals();
    const econ = useEconomy();
    const fmt = new Intl.NumberFormat("pt-BR");

    const adenaDisplay =
        econ.status === "live"
            ? fmt.format(econ.value)
            : econ.status === "error"
              ? "SEM DADOS"
              : "SINCRONIZANDO…";

    return (
        <section
            className="vb-section vb-section--bg"
            style={{
                backgroundImage: `linear-gradient(180deg, rgba(3,8,16,.70), rgba(3,6,12,.92)), url("${VB_ASSETS.bg.economy}")`,
            }}
        >
            <div className="vb-grid-bg" aria-hidden="true" />
            <div className="vb-wrap">
                <div className="vb-section-head centered" data-reveal>
                    <span className="vb-kicker">VIRTUAL BOOST · MOEDAS DO REINO</span>
                    <h2 className="vb-title">
                        UMA ECONOMIA <span className="accent">EM TEMPO REAL</span>
                    </h2>
                    <p className="vb-lead">
                        <strong>Adena</strong>, <strong>VBSilver</strong> e{" "}
                        <strong>VBGold</strong> movimentam o reino. Transparência sobre Adena em
                        circulação, atualizada direto das tabelas do servidor.
                    </p>
                    <div className="vb-title-line" data-reveal="mask" />
                </div>

                <div className="vb-econ-grid">
                    {/* ADENA — dado vivo */}
                    <article
                        className="vb-panel vb-panel--hud vb-coin-card vb-coin-card--adena"
                        data-reveal
                        style={{ "--d": 0 } as React.CSSProperties}
                    >
                        <span className="vb-sheen" aria-hidden="true" />
                        <span className="vb-coin-glow" aria-hidden="true" />
                        <div className="vb-coin-icon-wrap" aria-hidden="true">
                            <svg viewBox="0 0 48 48" width="52" height="52" fill="none" stroke="currentColor" style={{ color: "var(--gold-bright)" }}>
                                <circle cx="24" cy="24" r="18" strokeWidth="2.4" />
                                <circle cx="24" cy="24" r="12.5" strokeWidth="1.2" opacity=".6" />
                                <path d="M24 15.5v17M18.6 20.4c1.2-1.9 3.1-2.8 5.4-2.8 3.4 0 5.6 1.7 5.6 4.1 0 2.2-1.5 3.3-4 3.8l-4.6.9c-2.6.5-4 1.9-4 4.1 0 2.5 2.3 4.2 5.7 4.2 2.4 0 4.4-1 5.5-2.9" strokeWidth="1.9" strokeLinecap="round" />
                            </svg>
                        </div>
                        <div className="vb-coin-name">Adena</div>
                        <div
                            className={`vb-coin-value${econ.status !== "live" ? (econ.status === "error" ? " is-error" : " is-loading") : ""}`}
                            aria-live="polite"
                        >
                            {adenaDisplay}
                        </div>
                        <p className="vb-coin-note">
                            Base da economia: comércio, equipamentos, crafting e negociações.
                        </p>
                        <span className="vb-coin-status vb-coin-status--gold">
                            <i className="vb-dot" aria-hidden="true" />
                            {econ.status === "live"
                                ? "ATUALIZAÇÃO A CADA 5S"
                                : econ.status === "error"
                                  ? "RECONECTANDO…"
                                  : "SINCRONIZANDO"}
                        </span>
                    </article>

                    {/* VBSILVER */}
                    <article
                        className="vb-panel vb-panel--hud vb-coin-card vb-coin-card--silver"
                        data-reveal
                        style={{ "--d": 1 } as React.CSSProperties}
                    >
                        <span className="vb-sheen" aria-hidden="true" />
                        <span className="vb-coin-glow" aria-hidden="true" />
                        <div className="vb-coin-icon-wrap" aria-hidden="true">
                            <img src={VB_ASSETS.season.silver} alt="" width={48} height={48} />
                        </div>
                        <div className="vb-coin-name">VBSilver</div>
                        <p className="vb-coin-note" style={{ marginTop: 18 }}>
                            Moeda de atividade: obtida através de eventos, PvP, missões e
                            participação no servidor.
                        </p>
                        <span className="vb-coin-status">
                            <i className="vb-dot" aria-hidden="true" />
                            ATIVIDADE DO REINO
                        </span>
                    </article>

                    {/* VB GOLD */}
                    <article
                        className="vb-panel vb-panel--hud vb-coin-card vb-coin-card--gold"
                        data-reveal
                        style={{ "--d": 2 } as React.CSSProperties}
                    >
                        <span className="vb-sheen" aria-hidden="true" />
                        <span className="vb-coin-glow" aria-hidden="true" />
                        <div className="vb-coin-icon-wrap" aria-hidden="true">
                            <img src={VB_ASSETS.season.gold} alt="" width={48} height={48} />
                        </div>
                        <div className="vb-coin-name">VBGold</div>
                        <p className="vb-coin-note" style={{ marginTop: 18 }}>
                            Moeda de prestígio: destinada a recompensas raras, conteúdo especial e
                            progressão de endgame.
                        </p>
                        <span className="vb-coin-status vb-coin-status--gold">
                            <i className="vb-dot" aria-hidden="true" />
                            PRESTÍGIO
                        </span>
                    </article>
                </div>

                {/* painel de dados do reino (mesma origem dos painéis oficiais) */}
                <div className="vb-econ-data">
                    <div
                        className="vb-panel vb-econ-data-item"
                        data-reveal
                        style={{ "--d": 0 } as React.CSSProperties}
                    >
                        <span className="vb-sheen" aria-hidden="true" />
                        <span className="vb-econ-data-ico" aria-hidden="true">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
                                <path d="M4 21V9l8-5 8 5v12" />
                                <path d="M4 21h16M9 21v-6h6v6" />
                            </svg>
                        </span>
                        <div>
                            <b>Tesouro dos Castelos — 9.000.000</b>
                            <small>Acumulado via Taxas de Domínio</small>
                        </div>
                    </div>
                    <button
                        type="button"
                        className="vb-panel vb-econ-data-item"
                        style={{ cursor: "pointer", textAlign: "left", "--d": 1 } as React.CSSProperties}
                        data-reveal
                        onClick={() => openPanel("economy")}
                    >
                        <span className="vb-sheen" aria-hidden="true" />
                        <span className="vb-econ-data-ico" aria-hidden="true">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
                                <path d="M3 17l5-5 4 4 7-8" />
                                <path d="M15 8h4v4" />
                            </svg>
                        </span>
                        <div>
                            <b>Volume de Transações (24h) — 195 Itens</b>
                            <small>Movimentações no Auction / Trade · ver painel completo →</small>
                        </div>
                    </button>
                </div>
            </div>
        </section>
    );
}
