"use client";

import { VB_ASSETS } from "@/lib/assets";

const FEATURES = [
    {
        img: VB_ASSETS.cards.progressao,
        n: "01",
        title: "PROGRESSÃO DINÂMICA",
        text: "Uma jornada acelerada sem eliminar o valor da conquista.",
    },
    {
        img: VB_ASSETS.cards.economia,
        n: "02",
        title: "ECONOMIA VIVA",
        text: "Adena, materiais, crafting e comércio movimentam o reino.",
    },
    {
        img: VB_ASSETS.cards.concorrencia,
        n: "03",
        title: "COMPETIÇÃO DE VERDADE",
        text: "Clãs, territórios, guerras e conquistas definem os grandes nomes.",
    },
    {
        img: VB_ASSETS.cards.protecao,
        n: "04",
        title: "PROTEÇÃO ATIVA",
        text: "Administração presente e ambiente competitivo protegido.",
    },
    {
        img: VB_ASSETS.cards.crafting,
        n: "05",
        title: "CRAFTING RELEVANTE",
        text: "Produzir, coletar e negociar fazem parte da evolução.",
    },
];

export default function FeaturesSection() {
    return (
        <section
            id="features"
            className="vb-section vb-section--bg"
            style={{
                backgroundImage: `linear-gradient(180deg, rgba(3,8,16,.70), rgba(3,6,12,.90)), url("${VB_ASSETS.bg.features}")`,
            }}
        >
            <div className="vb-wrap">
                <div className="vb-section-head centered" data-reveal>
                    <span className="vb-kicker">A ESSÊNCIA DO SERVIDOR</span>
                    <h2 className="vb-title">
                        MEMÓRIAS DA JUVENTUDE
                        <br />
                        <span className="accent">GANHAM VIDA</span>
                    </h2>
                    <p className="vb-lead">
                        Preservamos a essência do Lineage II e adicionamos novos recursos para
                        transformar sua experiência.
                    </p>
                    <div className="vb-title-line" data-reveal="mask" />
                </div>

                <div className="vb-feature-list">
                    {FEATURES.map((f, i) => (
                        <article
                            className="vb-panel vb-panel--hud"
                            key={f.n}
                            data-reveal
                            style={{ "--d": i } as React.CSSProperties}
                        >
                            <span className="vb-sheen" aria-hidden="true" />
                            <div className="vb-feature-card-img-wrap">
                                <img
                                    className="vb-feature-card-img"
                                    src={f.img}
                                    alt={f.title}
                                    loading="lazy"
                                    decoding="async"
                                />
                            </div>
                            <div className="vb-feature-body">
                                <small aria-hidden="true">{f.n}</small>
                                <h3>{f.title}</h3>
                                <p>{f.text}</p>
                            </div>
                        </article>
                    ))}
                </div>
            </div>
        </section>
    );
}
