"use client";

import { VB_ASSETS } from "@/lib/assets";

const NEWS = [
    { n: "01", title: "AUTO FARM", tag: "NOVO" },
    { n: "02", title: "INTERFACE NOVA", tag: "ATUALIZADA" },
    { n: "03", title: "NOVO LOGIN", tag: "EM DESTAQUE" },
    { n: "04", title: "NOVIDADES DO REINO", tag: "ONLINE" },
];

export default function LiveSection() {
    return (
        <section
            id="novidades"
            className="vb-section vb-section--bg"
            style={{
                backgroundImage: `linear-gradient(180deg, rgba(3,8,16,.72), rgba(3,6,12,.90)), url("${VB_ASSETS.bg.live}")`,
            }}
        >
            <div className="vb-grid-bg" aria-hidden="true" />
            <div className="vb-wrap">
                <div className="vb-section-head" data-reveal>
                    <span className="vb-kicker">TRANSMISSÕES DA COMUNIDADE</span>
                    <h2 className="vb-title">
                        VIRTUAL BOOST <span className="accent">AO VIVO</span>
                    </h2>
                    <p className="vb-lead">
                        Sieges, Olympiads, Clan Wars, Epic Bosses e Raid Bosses. Acompanhe a
                        comunidade e tudo que acontece no reino.
                    </p>
                    <div className="vb-title-line" data-reveal="mask" />
                </div>

                <div className="vb-live-grid">
                    <div className="vb-panel vb-panel--hud vb-beam vb-live-player" data-reveal="left">
                        <span className="vb-sheen" aria-hidden="true" />
                        <span className="vb-beam-line" aria-hidden="true" />
                        <div className="vb-live-frame">
                            <iframe
                                src={VB_ASSETS.links.youtubeLive}
                                title="Porque jogar Virtual Boost em 2026"
                                loading="lazy"
                                allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                allowFullScreen
                            />
                        </div>
                        <div className="vb-live-bar">
                            <span>
                                <i className="vb-dot" aria-hidden="true" />
                                VIRTUAL BOOST - 2026
                            </span>
                            <b>AUTO FARM ATUALIZADO</b>
                        </div>
                    </div>

                    <div className="vb-panel vb-news-panel" data-reveal="right">
                        <span className="vb-sheen" aria-hidden="true" />
                        <small>NOVIDADES</small>
                        <h3>NOVIDADES DO VIRTUAL BOOST</h3>
                        {NEWS.map((n, i) => (
                            <div
                                className="vb-news-item"
                                key={n.n}
                                data-reveal="fade"
                                style={{ "--d": i + 1 } as React.CSSProperties}
                            >
                                <i aria-hidden="true">{n.n}</i>
                                <b>{n.title}</b>
                                <span>{n.tag}</span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
}
