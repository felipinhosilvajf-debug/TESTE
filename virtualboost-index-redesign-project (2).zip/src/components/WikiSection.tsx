"use client";

import { VB_ASSETS } from "@/lib/assets";
import { useTilt } from "@/lib/hooks";
import { useModals, type PanelKey } from "./ModalsContext";

const WIKI_CARDS: {
    img: string;
    tag: string;
    title: string;
    text: string;
    panel: PanelKey;
}[] = [
    {
        img: VB_ASSETS.cards.concorrencia,
        tag: "SISTEMAS",
        title: "O REINO E SEUS SISTEMAS",
        text: "Entenda como funciona o servidor e comece sua jornada.",
        panel: "server",
    },
    {
        img: VB_ASSETS.cards.economia,
        tag: "ECONOMIA",
        title: "ECONOMIA EM TEMPO REAL",
        text: "Acompanhe a movimentação de Adena e do mercado.",
        panel: "economy",
    },
    {
        img: VB_ASSETS.cards.progressao,
        tag: "COMEÇO RÁPIDO",
        title: "RATES DO SERVIDOR",
        text: "Confira as regras e números que definem a progressão.",
        panel: "rates",
    },
];

function WikiCard({
    card,
    delay,
}: {
    card: (typeof WIKI_CARDS)[number];
    delay: number;
}) {
    const { openPanel } = useModals();
    const tiltRef = useTilt<HTMLElement>(3);

    return (
        <article
            className="vb-panel vb-panel--hud vb-wiki-card"
            ref={tiltRef}
            data-reveal
            style={{ "--d": delay } as React.CSSProperties}
        >
            <span className="vb-sheen" aria-hidden="true" />
            <div className="vb-wiki-card-img-wrap">
                <img
                    className="vb-wiki-card-img"
                    src={card.img}
                    alt={card.title}
                    loading="lazy"
                    decoding="async"
                />
            </div>
            <div className="vb-wiki-body">
                <small>{card.tag}</small>
                <h3>{card.title}</h3>
                <p>{card.text}</p>
                <button
                    type="button"
                    className="vb-wiki-link"
                    onClick={() => openPanel(card.panel)}
                >
                    SABER MAIS <span aria-hidden="true">→</span>
                </button>
            </div>
        </article>
    );
}

export default function WikiSection() {
    return (
        <section
            id="wiki"
            className="vb-section vb-section--bg"
            style={{
                backgroundImage: `linear-gradient(180deg, rgba(3,8,16,.70), rgba(3,6,12,.92)), url("${VB_ASSETS.bg.wiki}")`,
            }}
        >
            <div className="vb-grid-bg" aria-hidden="true" />
            <div className="vb-wrap">
                <div className="vb-section-head" data-reveal>
                    <span className="vb-kicker">CONHECIMENTO DO REINO</span>
                    <h2 className="vb-title">
                        WIKI EM <span className="accent">DESTAQUE</span>
                    </h2>
                    <p className="vb-lead">
                        Rates, economia, sistemas, mapas e tudo que impacta diretamente sua
                        jornada.
                    </p>
                    <div className="vb-title-line" data-reveal="mask" />
                </div>

                <div className="vb-wiki-grid">
                    {WIKI_CARDS.map((c, i) => (
                        <WikiCard key={c.tag} card={c} delay={i} />
                    ))}
                </div>
            </div>
        </section>
    );
}
