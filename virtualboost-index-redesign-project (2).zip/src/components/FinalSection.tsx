"use client";

import { VB_ASSETS } from "@/lib/assets";
import { useModals } from "./ModalsContext";

export default function FinalSection() {
    const { openPanel } = useModals();

    return (
        <section className="vb-section">
            <div className="vb-wrap">
                <div
                    className="vb-final-frame vb-beam"
                    data-reveal="fade"
                    style={{
                        "--final-bg": `url("${VB_ASSETS.bg.final}")`,
                    } as React.CSSProperties}
                >
                    <span className="vb-beam-line" aria-hidden="true" />
                    <small data-reveal>CHRONICLE HIGH FIVE · VIRTUAL BOOST</small>
                    <h2 data-reveal style={{ "--d": 1 } as React.CSSProperties}>
                        SUA LENDA
                        <br />
                        <span>COMEÇA AQUI.</span>
                    </h2>
                    <p data-reveal style={{ "--d": 2 } as React.CSSProperties}>
                        Prepare seu personagem. Reúna seus aliados. Entre no reino.
                    </p>
                    <button
                        type="button"
                        className="vb-btn"
                        data-reveal
                        style={{ "--d": 3 } as React.CSSProperties}
                        onClick={() => openPanel("download")}
                    >
                        BAIXAR O JOGO <span className="vb-btn-arrow" aria-hidden="true">→</span>
                    </button>
                </div>
            </div>
        </section>
    );
}
