"use client";

import { VB_ASSETS } from "@/lib/assets";

/**
 * ROLETA DA TEMPORADA
 * A rotação acontece no elemento .vb-season-rotor (inset 0), que gira
 * 360° de forma linear e contínua, controlada pela variável original
 * --wheel-speed (350s) declarada em :root. Os 9 itens mantêm as
 * posições validadas do projeto original e ficam contidos em círculos
 * com overflow oculto — nenhuma imagem ultrapassa a borda.
 * Pausa suave ao passar o mouse; respeita prefers-reduced-motion.
 */
const WHEEL_ITEMS = [
    { cls: "vb-season-item-1", img: VB_ASSETS.season.logo, alt: "Season 01", extra: "" },
    { cls: "vb-season-item-2", img: VB_ASSETS.season.mage3, alt: "Tattoo Mage LVL 3", extra: "vb-season-item--violet" },
    { cls: "vb-season-item-3", img: VB_ASSETS.season.mage2, alt: "Tattoo Mage LVL 2", extra: "vb-season-item--violet" },
    { cls: "vb-season-item-4", img: VB_ASSETS.season.mage1, alt: "Tattoo Mage LVL 1", extra: "vb-season-item--violet" },
    { cls: "vb-season-item-5", img: VB_ASSETS.season.silver, alt: "VBSilver", extra: "" },
    { cls: "vb-season-item-6", img: VB_ASSETS.season.fight1, alt: "Tattoo Fight LVL 1", extra: "" },
    { cls: "vb-season-item-7", img: VB_ASSETS.season.fight2, alt: "Tattoo Fight LVL 2", extra: "" },
    { cls: "vb-season-item-8", img: VB_ASSETS.season.fight3, alt: "Tattoo Fight LVL 3", extra: "" },
    { cls: "vb-season-item-9", img: VB_ASSETS.season.gold, alt: "VBGold", extra: "vb-season-item--gold" },
];

const SEASON_CARDS = [
    {
        img: VB_ASSETS.season.silver,
        name: "VBSilver",
        desc: "Moeda definitiva de atividade.",
        variant: "vb-season-card--silver",
    },
    {
        img: VB_ASSETS.season.gold,
        name: "VBGold",
        desc: "Prestígio e recompensas raras.",
        variant: "vb-season-card--gold",
    },
    {
        img: VB_ASSETS.season.mage3,
        name: "VBMage",
        desc: "Progressão das marcas arcanas.",
        variant: "vb-season-card--mage",
    },
    {
        img: VB_ASSETS.season.fight3,
        name: "VBFight",
        desc: "Progressão das marcas de combate.",
        variant: "vb-season-card--fight",
    },
];

export default function SeasonSection() {
    return (
        <section
            id="progressao"
            className="vb-section vb-section--bg"
            style={{
                backgroundImage: `linear-gradient(180deg, rgba(3,8,16,.66), rgba(3,6,12,.92)), url("${VB_ASSETS.bg.features}")`,
            }}
        >
            <div className="vb-grid-bg" aria-hidden="true" />
            <div className="vb-wrap">
                <div className="vb-section-head" data-reveal>
                    <span className="vb-kicker">VIRTUAL BOOST · TEMPORADA ATUAL</span>
                    <h2 className="vb-title">
                        UMA NOVA MARCA <span className="accent">PARA OS HERÓIS</span>
                    </h2>
                    <p className="vb-lead">
                        Uma temporada construída em torno de uma economia viva:{" "}
                        <strong>Adena</strong>, VBSilver e VBGold movimentam o reino, enquanto as
                        linhas <strong>VBMage</strong> e <strong>VBFight</strong> representam
                        novos caminhos de progressão e identidade.
                    </p>
                    <div className="vb-title-line" data-reveal="mask" />
                </div>

                <div className="vb-season-stage">
                    {/* ROLETA */}
                    <div className="vb-season-orbit-wrap" data-reveal="fade">
                        <div className="vb-season-aura" aria-hidden="true" />
                        <div className="vb-season-orbit" role="img" aria-label="Roleta da temporada com moedas e marcas do Virtual Boost">
                            <div className="vb-season-ring vb-season-ring-a" aria-hidden="true" />
                            <div className="vb-season-ring vb-season-ring-b" aria-hidden="true" />
                            <div className="vb-season-ticks" aria-hidden="true" />

                            <div className="vb-season-rotor" aria-hidden="true">
                                {WHEEL_ITEMS.map((it) => (
                                    <div
                                        key={it.cls}
                                        className={`vb-season-item ${it.cls} ${it.extra}`.trim()}
                                    >
                                        <img src={it.img} alt={it.alt} width={64} height={64} />
                                    </div>
                                ))}
                            </div>

                            <div className="vb-season-core">
                                <span>VB</span>
                                <small>SEASON 01</small>
                            </div>
                        </div>
                    </div>

                    {/* COPY + CARDS */}
                    <div className="vb-season-copy">
                        <span className="vb-kicker" data-reveal="left">
                            VIRTUAL BOOST · TEMPORADA ATUAL
                        </span>
                        <h3 data-reveal="left" style={{ "--d": 1 } as React.CSSProperties}>
                            AS NOVAS MARCAS DOS <span>VERDADEIROS HERÓIS</span>
                        </h3>
                        <p data-reveal="left" style={{ "--d": 2 } as React.CSSProperties}>
                            As tattoos são as novas marcas dos verdadeiros heróis do Virtual
                            Boost. Evolua sua identidade, conquiste recompensas e deixe seu nome
                            registrado no reino.
                        </p>
                        <div className="vb-season-cards">
                            {SEASON_CARDS.map((c, i) => (
                                <article
                                    key={c.name}
                                    className={`vb-season-card ${c.variant}`}
                                    data-reveal="left"
                                    style={{ "--d": i + 3 } as React.CSSProperties}
                                >
                                    <img src={c.img} alt="" width={44} height={44} />
                                    <div>
                                        <b>{c.name}</b>
                                        <small>{c.desc}</small>
                                    </div>
                                </article>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}
