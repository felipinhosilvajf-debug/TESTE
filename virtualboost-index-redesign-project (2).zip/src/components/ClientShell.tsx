"use client";

import { useRevealObserver } from "@/lib/hooks";
import { ModalsProvider, useModals } from "./ModalsContext";
import Navbar from "./Navbar";
import Hero from "./Hero";
import LiveSection from "./LiveSection";
import FeaturesSection from "./FeaturesSection";
import EconomySection from "./EconomySection";
import SeasonSection from "./SeasonSection";
import WikiSection from "./WikiSection";
import FinalSection from "./FinalSection";
import Footer from "./Footer";
import { CursorGlow, Floats, ParticleField } from "./fx";

function Shell() {
    const { openPanel } = useModals();

    return (
        <>
            <ParticleField />
            <CursorGlow />
            <Navbar />
            <main className="vb-main">
                <Hero />
                <LiveSection />
                <FeaturesSection />
                <EconomySection />
                <SeasonSection />
                <WikiSection />
                <FinalSection />
            </main>
            <Footer />
            <Floats onDiscord={() => openPanel("join")} />
        </>
    );
}

export default function ClientShell() {
    useRevealObserver();

    return (
        <ModalsProvider>
            <Shell />
        </ModalsProvider>
    );
}
