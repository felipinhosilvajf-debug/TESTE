"use client";

import { useEffect, useRef } from "react";
import { VB_ASSETS } from "@/lib/assets";
import { useOnlineSince } from "@/lib/hooks";
import { useModals } from "./ModalsContext";

export default function Hero() {
    const { openPanel } = useModals();
    const since = useOnlineSince();
    const mediaRef = useRef<HTMLDivElement | null>(null);
    const haloRef = useRef<HTMLDivElement | null>(null);

    /* parallax sutil do cenário com o cursor — apenas desktop, pointer fine */
    useEffect(() => {
        const fine = window.matchMedia("(pointer: fine)").matches;
        const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        if (!fine || reduce) return;

        let raf = 0;
        let tx = 0, ty = 0, cx = 0, cy = 0;
        const onMove = (e: MouseEvent) => {
            tx = (e.clientX / window.innerWidth - 0.5) * 2;
            ty = (e.clientY / window.innerHeight - 0.5) * 2;
        };
        const loop = () => {
            cx += (tx - cx) * 0.045;
            cy += (ty - cy) * 0.045;
            if (mediaRef.current) {
                mediaRef.current.style.transform = `translate3d(${(cx * -8).toFixed(2)}px, ${(cy * -6).toFixed(2)}px, 0)`;
            }
            if (haloRef.current) {
                haloRef.current.style.translate = `${(cx * 18).toFixed(2)}px ${(cy * 14).toFixed(2)}px`;
            }
            raf = requestAnimationFrame(loop);
        };
        window.addEventListener("mousemove", onMove, { passive: true });
        raf = requestAnimationFrame(loop);
        return () => {
            window.removeEventListener("mousemove", onMove);
            cancelAnimationFrame(raf);
        };
    }, []);

    return (
        <section id="home" className="vb-hero">
            <div className="vb-hero-media" ref={mediaRef} aria-hidden="true">
                <video
                    className="vb-hero-video"
                    autoPlay
                    muted
                    loop
                    playsInline
                    preload="auto"
                    poster={VB_ASSETS.heroPoster}
                >
                    <source src={VB_ASSETS.heroVideo} type="video/mp4" />
                </video>
                <div className="vb-hero-shade" />
            </div>

            <div className="vb-hero-halo" ref={haloRef} aria-hidden="true" />
            <div className="vb-hero-ring vb-hero-ring-a" aria-hidden="true" />
            <div className="vb-hero-ring vb-hero-ring-b" aria-hidden="true" />

            <div className="vb-hero-content">
                <div className="vb-hero-overline vb-hero-anim" style={{ "--d": 0 } as React.CSSProperties}>
                    PROJETO HIGH FIVE
                </div>
                <img
                    src={VB_ASSETS.logo}
                    alt="Virtual Boost"
                    className="vb-hero-logo vb-hero-anim"
                    style={{ "--d": 1 } as React.CSSProperties}
                    fetchPriority="high"
                    width={330}
                    height={330}
                />
                <h1 className="vb-hero-anim" style={{ "--d": 2 } as React.CSSProperties}>
                    SUA GRANDE HISTÓRIA
                    <br />
                    <em>COMEÇA AGORA!</em>
                </h1>
                <p className="vb-hero-sub vb-hero-anim" style={{ "--d": 3 } as React.CSSProperties}>
                    O Virtual Boost leva você a uma experiência MMORPG expansiva onde você cria
                    o seu próprio destino.
                </p>
                <div className="vb-hero-energy vb-hero-anim" style={{ "--d": 4 } as React.CSSProperties} aria-hidden="true" />
                <div className="vb-hero-anim" style={{ "--d": 5 } as React.CSSProperties}>
                    <div className="vb-hero-launch">
                        DESDE O LANÇAMENTO: <strong>{since}</strong>
                    </div>
                </div>
                <div className="vb-hero-cta vb-hero-anim" style={{ "--d": 6 } as React.CSSProperties}>
                    <button type="button" className="vb-btn" onClick={() => openPanel("download")}>
                        JOGAR AGORA <span className="vb-btn-arrow" aria-hidden="true">→</span>
                    </button>
                    <a className="vb-btn vb-btn--ghost" href="#features">
                        DESCOBRIR O REINO
                    </a>
                </div>
            </div>

            <a className="vb-scroll-hint" href="#novidades" aria-label="Rolar para novidades">
                ROLAR
                <i aria-hidden="true" />
            </a>
        </section>
    );
}
